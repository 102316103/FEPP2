#!/bin/bash

optUser=fep
optUserDir=/$optUser
jarFile=$optUserDir/fep-app/fep-gateway-fisc/fep-gateway-fisc-1.0.0.jar
programName=com.syscom.fep.gateway.cmd.FISCGatewayCommand

function usage() {
:<<!
  if [ "$USER" != "$optUser" -o "$HOME" != "$optUserDir" ]; then
    echo "Warning! you must be user $optUser..."
    exit 1
  fi
!
  echo "Usage: $0 {monitor action}"
  echo "Example: $0 monitor get"
  exit 1
}

function monitor() {
:<<!
  if [ "$USER" != "$optUser" -o "$HOME" != "$optUserDir" ]; then
    echo "Warning! you must be user $optUser..."
    exit 1
  fi
!
  java -Dfile.encoding=UTF-8 -cp $jarFile $programName -f monitor -d "action=$1"
}

case $1 in
monitor)
  monitor $2
  ;;

*)
  usage
  ;;
esac
