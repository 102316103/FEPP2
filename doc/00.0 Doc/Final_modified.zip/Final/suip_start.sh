#!/bin/bash

optUser=fep
cd /$optUser/fep-app/suip/TCB/exe
cd /fep/fep-app/suip/TCB/exe
./suipsrv
