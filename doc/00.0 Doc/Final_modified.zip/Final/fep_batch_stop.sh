#!/bin/bash

optUser=fep
fepFunctionPath=/$optUser/fep-app/bin/fep_function.sh
$fepFunctionPath stop fep-batch-1.0.0.jar