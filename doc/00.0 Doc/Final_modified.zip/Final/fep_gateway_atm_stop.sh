#!/bin/bash

optUser=fep
fepFunctionPath=/$optUser/fep-app/bin/fep_function.sh
$fepFunctionPath stop fep-gateway-atm-1.0.0.jar