#!/bin/bash

optUser=fep
cd /$optUser/fep-app/suip/TCB/exe
killall -KILL suipsrv1