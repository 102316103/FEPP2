#!/bin/bash

optUser=fep
fepFunctionPath=/$optUser/fep-app/bin/fep_function.sh
$fepFunctionPath start fep-gateway-fisc-1.0.0.jar